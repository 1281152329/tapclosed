var ht=Object.defineProperty;var ft=(x,g,k)=>g in x?ht(x,g,{enumerable:!0,configurable:!0,writable:!0,value:k}):x[g]=k;var c=(x,g,k)=>ft(x,typeof g!="symbol"?g+"":g,k);(function(){"use strict";const x={closeHoldMs:200,moveThreshold:15,closeCooldownMs:800};class g{constructor(e,o={}){c(this,"opts");c(this,"handler");c(this,"leftDown",!1);c(this,"rightDown",!1);c(this,"middleDown",!1);c(this,"startX",0);c(this,"startY",0);c(this,"closeTimer",null);c(this,"lastCloseTime",0);c(this,"gestureActive",!1);c(this,"bothConfirmed",!1);c(this,"_onMouseDown");c(this,"_onMouseUp");c(this,"_onMouseMove");c(this,"_onContextMenu");c(this,"_onWheel");c(this,"_onResetState");c(this,"_onDragStart");this.handler=e,this.opts={...x,...o},this._onMouseDown=this.onMouseDown.bind(this),this._onMouseUp=this.onMouseUp.bind(this),this._onMouseMove=this.onMouseMove.bind(this),this._onContextMenu=this.onContextMenu.bind(this),this._onWheel=this.onWheel.bind(this),this._onResetState=this.resetState.bind(this),this._onDragStart=n=>{this.gestureActive&&n.preventDefault()}}attach(){const e={capture:!0,passive:!1};return document.addEventListener("mousedown",this._onMouseDown,e),document.addEventListener("mouseup",this._onMouseUp,e),document.addEventListener("mousemove",this._onMouseMove,e),document.addEventListener("contextmenu",this._onContextMenu,e),document.addEventListener("wheel",this._onWheel,e),document.addEventListener("dragstart",this._onDragStart,e),window.addEventListener("mouseup",this._onMouseUp,e),window.addEventListener("blur",this._onResetState),document.addEventListener("visibilitychange",this._onResetState),()=>this.detach()}detach(){document.removeEventListener("mousedown",this._onMouseDown,!0),document.removeEventListener("mouseup",this._onMouseUp,!0),document.removeEventListener("mousemove",this._onMouseMove,!0),document.removeEventListener("contextmenu",this._onContextMenu,!0),document.removeEventListener("wheel",this._onWheel,!0),document.removeEventListener("dragstart",this._onDragStart,!0),window.removeEventListener("mouseup",this._onMouseUp,!0),window.removeEventListener("blur",this._onResetState),document.removeEventListener("visibilitychange",this._onResetState),this.resetState()}onMouseDown(e){this.isInput(e.target)||(this.rightDown,this.leftDown,e.button===0&&(this.leftDown=!0,this.rightDown||(this.startX=e.clientX,this.startY=e.clientY)),e.button===1&&(this.middleDown=!0),e.button===2&&(this.rightDown=!0,this.leftDown||(this.startX=e.clientX,this.startY=e.clientY)),(this.leftDown||this.rightDown||this.middleDown)&&(this.gestureActive=!0),this.leftDown&&this.rightDown&&!this.closeTimer&&(e.preventDefault(),this.bothConfirmed=!0,console.log("[tapclosed:gesture] both buttons down, starting hold timer"),this.closeTimer=setTimeout(()=>{this.closeTimer=null;const o=Date.now();if(o-this.lastCloseTime<this.opts.closeCooldownMs){console.log("[tapclosed:gesture] cooldown active");return}this.lastCloseTime=o,console.log("[tapclosed:gesture] CLOSE fired!"),this.handler({type:"CLOSE"}),this.resetState()},this.opts.closeHoldMs)))}onMouseUp(e){e.button===0&&(this.leftDown=!1),e.button===1&&(this.middleDown=!1),e.button===2&&(this.rightDown=!1),!(this.bothConfirmed&&this.closeTimer)&&(!this.leftDown&&!this.rightDown&&!this.middleDown?(this.gestureActive=!1,this.bothConfirmed=!1,this.cancelClose()):this.closeTimer&&(!this.leftDown||!this.rightDown)&&this.cancelClose())}onMouseMove(e){if(!this.closeTimer)return;const o=e.clientX-this.startX,n=e.clientY-this.startY;o*o+n*n>this.opts.moveThreshold*this.opts.moveThreshold&&(console.log("[tapclosed:gesture] cancelled �?moved too far"),this.cancelClose())}onContextMenu(e){this.gestureActive&&(e.preventDefault(),e.stopPropagation(),e.stopImmediatePropagation())}onWheel(e){this.isInput(e.target)||!this.rightDown||this.leftDown||this.middleDown||(e.preventDefault(),e.stopPropagation(),e.deltaY<0?(console.log("[tapclosed:gesture] TAB_PREV"),this.handler({type:"TAB_PREV"})):e.deltaY>0&&(console.log("[tapclosed:gesture] TAB_NEXT"),this.handler({type:"TAB_NEXT"})))}cancelClose(){this.closeTimer&&(clearTimeout(this.closeTimer),this.closeTimer=null),this.bothConfirmed=!1}resetState(){this.leftDown=!1,this.rightDown=!1,this.middleDown=!1,this.gestureActive=!1,this.bothConfirmed=!1,this.cancelClose()}isInput(e){if(!e||!(e instanceof HTMLElement))return!1;const o=e.tagName;return!!(o==="INPUT"||o==="TEXTAREA"||o==="SELECT"||e.isContentEditable||e.closest(".monaco-editor")||e.closest(".CodeMirror"))}}function k(t){const{duration:e,easing:o,keyframes:n,onUpdate:s,onComplete:i}=t;let a=null,l,m=!1;function p(u,y){let w=u[0],_=u[u.length-1];for(let b=0;b<u.length-1;b++)if(y>=u[b].time&&y<=u[b+1].time){w=u[b],_=u[b+1];break}const O=_.time-w.time,pt=O>0?(y-w.time)/O:1,Q={};for(const b of Object.keys(w.values)){const V=w.values[b],ut=_.values[b]??V;Q[b]=V+(ut-V)*pt}return Q}function h(u){if(m)return;a===null&&(a=u);const y=u-a,w=Math.min(y/e,1),_=o(w),O=p(n,_);s(O),w<1?l=requestAnimationFrame(h):i?.()}return l=requestAnimationFrame(h),()=>{m=!0,cancelAnimationFrame(l)}}const Z=t=>t<.3?2.5*t*t:1-Math.pow(1-t,4)*.3,z="[tapclosed]",L={info:(...t)=>{},warn:(...t)=>{console.warn(z,...t)},error:(...t)=>{console.error(z,...t)},gesture:(...t)=>{},animation:(...t)=>{}};function J(t={}){const{duration:e=280,onComplete:o}=t,n=document.documentElement,s=document.createElement("div");s.id="tapclosed-dissolve-overlay",Object.assign(s.style,{position:"fixed",inset:"0",zIndex:"2147483646",pointerEvents:"none",background:"rgba(255, 255, 255, 0.04)",backdropFilter:"blur(0px)",WebkitBackdropFilter:"blur(0px)",opacity:"0",willChange:"opacity, backdrop-filter",transition:"none"}),document.body.appendChild(s);const i=k({duration:e,easing:Z,keyframes:[{time:0,values:{opacity:1,blur:0,scale:1,overlayOpacity:0}},{time:.4,values:{opacity:.85,blur:3,scale:.99,overlayOpacity:.3}},{time:.7,values:{opacity:.5,blur:8,scale:.97,overlayOpacity:.6}},{time:1,values:{opacity:0,blur:16,scale:.95,overlayOpacity:.9}}],onUpdate:a=>{n.style.opacity=String(a.opacity),n.style.transform=`scale(${a.scale})`,n.style.transformOrigin="center center",n.style.filter=`blur(${a.blur}px)`,n.style.willChange="opacity, transform, filter",s.style.opacity=String(a.overlayOpacity),s.style.backdropFilter=`blur(${a.blur*.5}px)`,s.style.WebkitBackdropFilter=`blur(${a.blur*.5}px)`},onComplete:()=>{o?.()}});return()=>{i(),s.remove(),n.style.opacity="",n.style.transform="",n.style.filter="",n.style.willChange=""}}let C=null;function B(){return C||(C=new AudioContext),C}function U(t){t.state==="suspended"&&t.resume()}function tt(t,e){const o=t.sampleRate,n=o*e,s=t.createBuffer(1,n,o),i=s.getChannelData(0);for(let a=0;a<n;a++)i[a]=(Math.random()*2-1)*.3;return s}function et(t){if(t.enabled)try{const e=B();U(e);const o=.25,n=e.createBufferSource();n.buffer=tt(e,o);const s=e.createBiquadFilter();s.type="bandpass",s.frequency.value=800,s.Q.value=.5;const i=e.createGain(),a=e.currentTime;i.gain.setValueAtTime(0,a),i.gain.linearRampToValueAtTime(t.volume*.4,a+.03),i.gain.exponentialRampToValueAtTime(.001,a+o),n.connect(s),s.connect(i),i.connect(e.destination),n.start(a),n.stop(a+o)}catch(e){L.warn("Sound playback failed:",e)}}function ot(t){if(t.enabled)try{const e=B();U(e);const o=.08,n=e.createOscillator();n.type="sine",n.frequency.value=600;const s=e.createGain(),i=e.currentTime;s.gain.setValueAtTime(t.volume*.2,i),s.gain.exponentialRampToValueAtTime(.001,i+o),n.connect(s),s.connect(e.destination),n.start(i),n.stop(i+o)}catch(e){L.warn("Sound playback failed:",e)}}const D={play(t,e){switch(t){case"close":et(e);break;case"undo":ot(e);break}},warmUp(){try{const t=B();U(t)}catch{}},isReady(){return C!==null&&C.state==="running"}};function Y(t,e){if(!e.length)return null;let o;try{o=new URL(t)}catch{return null}for(const n of e)if(n.enabled)switch(n.type){case"domain":{const s=n.pattern.toLowerCase(),i=o.hostname.toLowerCase();if(i===s||i.endsWith("."+s))return L.info("protected by rule:",n.label||n.pattern),n;break}case"exact":{if(o.href===n.pattern)return n;break}case"regex":{try{if(new RegExp(n.pattern,"i").test(o.href))return n}catch{L.warn("invalid regex rule:",n.pattern)}break}}return null}function nt(t){try{const n=new URL(t).hostname.toLowerCase().replace(/^www\./,""),s=n.split(".");if(s.length>2){const i=s[s.length-1],a=s[s.length-2];return i.length===2&&a.length<=3?s.slice(-3).join("."):s.slice(-2).join(".")}return n}catch{return""}}const S={enabled:!0,gestureEnabled:!0,soundEnabled:!0,soundVolume:.15,protectionRules:[{id:"1",pattern:"mail.google.com",type:"domain",enabled:!0,label:"Gmail"},{id:"2",pattern:"chat.openai.com",type:"domain",enabled:!0,label:"ChatGPT"},{id:"3",pattern:"docs.google.com",type:"domain",enabled:!0,label:"Google Docs"}],animationDuration:280,undoDuration:3e3},I="[tapclosed]",d=(...t)=>console.log(I,...t),st=(...t)=>console.warn(I,...t),X=(...t)=>console.error(I,...t);let j=!0;function E(){try{return chrome.runtime?.id?!0:(j=!1,!1)}catch{return j=!1,!1}}function v(t){if(E())try{chrome.runtime.sendMessage(t).catch(()=>{})}catch{}}let r=S,A=!1,T=null,R=!1,M=null;const it=1e3,at=30;let f=null;function P(){return f&&document.documentElement.contains(f)||(f=document.createElement("div"),f.id="tapclosed-overlay",Object.assign(f.style,{position:"fixed",inset:"0",zIndex:"2147483647",pointerEvents:"none",fontFamily:"-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif",fontSize:"13px",color:"rgba(255,255,255,0.9)"}),(document.body||document.documentElement).appendChild(f)),f}function N(t){d("showUndoToast",t.count,"tabs"),q();const e=P(),o=document.createElement("div");o.id="tapclosed-undo";const s=t.count>1?`${t.count} tabs closed`:t.tabs[0]?.title||"Tab closed";o.innerHTML=`
    <div class="tapclosed-undo-card">
      <div class="tapclosed-undo-progress"></div>
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style="flex-shrink:0;opacity:0.5">
        <path d="M4 4L12 12M4 12L12 4" stroke="rgba(255,255,255,0.7)" stroke-width="1.5" stroke-linecap="round"/>
      </svg>
      <div class="tapclosed-undo-title">${H(s)}</div>
      <button class="tapclosed-undo-btn">Undo</button>
    </div>
  `,Object.assign(o.style,{position:"fixed",bottom:"24px",right:"24px",zIndex:"2147483647",pointerEvents:"auto",opacity:"0",transform:"translateY(16px) scale(0.96)",transition:"opacity 0.25s cubic-bezier(0.23,1,0.32,1), transform 0.25s cubic-bezier(0.23,1,0.32,1)"});const i=document.createElement("style");i.textContent=`
    .tapclosed-undo-card {
      display:flex;align-items:center;gap:12px;padding:12px 16px;
      background:rgba(30,30,35,0.92);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);
      border:1px solid rgba(255,255,255,0.08);border-radius:14px;
      box-shadow:0 8px 32px rgba(0,0,0,0.4),0 0 0 1px rgba(255,255,255,0.04) inset;
      min-width:220px;overflow:hidden;position:relative;
    }
    .tapclosed-undo-progress {
      position:absolute;bottom:0;left:0;height:2px;
      background:linear-gradient(90deg,rgba(150,180,255,0.6),rgba(200,170,255,0.4));
      border-radius:0 0 14px 14px;transition:width 16ms linear;
    }
    .tapclosed-undo-title {
      flex:1;font-size:13px;font-weight:500;color:rgba(255,255,255,0.85);
      line-height:1.3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:180px;
    }
    .tapclosed-undo-btn {
      background:rgba(150,180,255,0.12);border:1px solid rgba(150,180,255,0.2);
      border-radius:8px;color:rgba(180,200,255,0.95);font-size:12px;font-weight:600;
      padding:5px 12px;cursor:pointer;font-family:inherit;letter-spacing:0.02em;
      transition:all 0.15s ease;white-space:nowrap;
    }
    .tapclosed-undo-btn:hover {
      background:rgba(150,180,255,0.2);border-color:rgba(150,180,255,0.35);
    }
  `,o.appendChild(i),e.appendChild(o),requestAnimationFrame(()=>{o.style.opacity="1",o.style.transform="translateY(0) scale(1)"}),o.querySelector(".tapclosed-undo-btn").addEventListener("click",()=>{v({type:"UNDO_CLOSE"}),q()});const l=r.undoDuration,m=Date.now(),p=o.querySelector(".tapclosed-undo-progress"),h=()=>{const u=Date.now()-m,y=Math.max(0,100-u/l*100);p.style.width=y+"%",y>0?T=requestAnimationFrame(h):q()};T=requestAnimationFrame(h)}function q(){T&&(cancelAnimationFrame(T),clearTimeout(T),T=null);const t=document.getElementById("tapclosed-undo");t&&(t.style.opacity="0",t.style.transform="translateY(8px) scale(0.98)",setTimeout(()=>t.remove(),300))}function G(t){d("showProtectionOverlay",t.label),W();const e=P(),o=document.createElement("div");o.id="tapclosed-protection",o.innerHTML=`
    <div class="tapclosed-prot-backdrop">
      <div class="tapclosed-prot-card">
        <div class="tapclosed-prot-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="rgba(150,180,255,0.7)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          </svg>
        </div>
        <div class="tapclosed-prot-title">This page is protected</div>
        <div class="tapclosed-prot-desc">${H(t.label||t.pattern)} is in your protected sites list.<br>Gesture close is disabled here.</div>
        <div class="tapclosed-prot-hint">Click anywhere to dismiss</div>
      </div>
    </div>
  `;const n=document.createElement("style");n.textContent=`
    .tapclosed-prot-backdrop {
      position:fixed;inset:0;display:flex;align-items:center;justify-content:center;
      background:rgba(0,0,0,0.3);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);
      pointer-events:auto;cursor:pointer;
      opacity:0;transition:opacity 0.3s ease;
    }
    .tapclosed-prot-card {
      display:flex;flex-direction:column;align-items:center;gap:16px;padding:32px 40px;
      background:rgba(25,25,30,0.88);backdrop-filter:blur(40px);-webkit-backdrop-filter:blur(40px);
      border:1px solid rgba(255,255,255,0.08);border-radius:20px;
      box-shadow:0 16px 64px rgba(0,0,0,0.5),0 0 0 1px rgba(255,255,255,0.03) inset;
      text-align:center;max-width:320px;
      opacity:0;transform:scale(0.94) translateY(10px);
      transition:opacity 0.35s cubic-bezier(0.23,1,0.32,1),transform 0.35s cubic-bezier(0.23,1,0.32,1);
    }
    .tapclosed-prot-icon {
      width:48px;height:48px;border-radius:50%;
      background:rgba(150,180,255,0.08);display:flex;align-items:center;justify-content:center;
      border:1px solid rgba(150,180,255,0.12);
    }
    .tapclosed-prot-title {font-size:15px;font-weight:600;color:rgba(255,255,255,0.9);letter-spacing:-0.01em}
    .tapclosed-prot-desc {font-size:13px;color:rgba(255,255,255,0.45);line-height:1.5}
    .tapclosed-prot-hint {font-size:11px;color:rgba(255,255,255,0.25);margin-top:4px}
  `,o.appendChild(n),e.appendChild(o),requestAnimationFrame(()=>{const s=o.querySelector(".tapclosed-prot-backdrop"),i=o.querySelector(".tapclosed-prot-card");s.style.opacity="1",setTimeout(()=>{i.style.opacity="1",i.style.transform="scale(1) translateY(0)"},50)}),o.addEventListener("click",W)}function W(){const t=document.getElementById("tapclosed-protection");t&&(t.style.opacity="0",setTimeout(()=>t.remove(),300))}function rt(){F(),R=!0;const t=nt(window.location.href),e=P(),o=document.createElement("div");o.id="tapclosed-options-popup",o.innerHTML=`
    <div class="tapclosed-opts-backdrop">
      <div class="tapclosed-opts-card">
        <div class="tapclosed-opts-header">
          <div class="tapclosed-opts-title">Close Tabs</div>
          <button class="tapclosed-opts-close" aria-label="Close">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M3 3L13 13M13 3L3 13" stroke="rgba(255,255,255,0.6)" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
          </button>
        </div>
        <div class="tapclosed-opts-body">
          <button class="tapclosed-opts-option" data-action="domain">
            <div class="tapclosed-opts-option-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(150,180,255,0.8)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <path d="M2 12h20"/>
              </svg>
            </div>
            <div class="tapclosed-opts-option-content">
              <div class="tapclosed-opts-option-title">Same Domain</div>
              <div class="tapclosed-opts-option-desc">Close all tabs with domain ${H(t||"")}</div>
            </div>
          </button>
          <button class="tapclosed-opts-option" data-action="other">
            <div class="tapclosed-opts-option-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(255,180,150,0.8)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <path d="M3 9h18"/>
              </svg>
            </div>
            <div class="tapclosed-opts-option-content">
              <div class="tapclosed-opts-option-title">Other Tabs</div>
              <div class="tapclosed-opts-option-desc">Close all tabs except this one</div>
            </div>
          </button>
          <button class="tapclosed-opts-option" data-action="all">
            <div class="tapclosed-opts-option-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(255,120,120,0.8)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <path d="M3 6h18"/>
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/>
                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>
              </svg>
            </div>
            <div class="tapclosed-opts-option-content">
              <div class="tapclosed-opts-option-title">All Tabs</div>
              <div class="tapclosed-opts-option-desc">Close all tabs in this window</div>
            </div>
          </button>
          <div class="tapclosed-opts-divider"></div>
          <button class="tapclosed-opts-option" data-action="duplicate">
            <div class="tapclosed-opts-option-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgba(150,200,170,0.8)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                <rect x="9" y="9" width="13" height="13" rx="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
              </svg>
            </div>
            <div class="tapclosed-opts-option-content">
              <div class="tapclosed-opts-option-title">Duplicate Tab</div>
              <div class="tapclosed-opts-option-desc">Copy this tab to a new tab</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  `;const n=document.createElement("style");n.textContent=`
    .tapclosed-opts-backdrop {
      position:fixed;inset:0;display:flex;align-items:center;justify-content:center;
      background:rgba(0,0,0,0.4);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);
      pointer-events:auto;
      opacity:0;transition:opacity 0.25s ease;
    }
    .tapclosed-opts-card {
      display:flex;flex-direction:column;
      background:rgba(25,25,30,0.92);backdrop-filter:blur(40px);-webkit-backdrop-filter:blur(40px);
      border:1px solid rgba(255,255,255,0.1);border-radius:18px;
      box-shadow:0 20px 80px rgba(0,0,0,0.6),0 0 0 1px rgba(255,255,255,0.03) inset;
      min-width:320px;max-width:400px;
      opacity:0;transform:scale(0.94) translateY(10px);
      transition:opacity 0.3s cubic-bezier(0.23,1,0.32,1),transform 0.3s cubic-bezier(0.23,1,0.32,1);
    }
    .tapclosed-opts-header {
      display:flex;align-items:center;justify-content:space-between;padding:20px 24px 16px;
      border-bottom:1px solid rgba(255,255,255,0.06);
    }
    .tapclosed-opts-title {
      font-size:16px;font-weight:600;color:rgba(255,255,255,0.9);letter-spacing:-0.01em;
    }
    .tapclosed-opts-close {
      width:28px;height:28px;border-radius:6px;
      background:transparent;border:1px solid rgba(255,255,255,0.1);
      cursor:pointer;color:rgba(255,255,255,0.5);
      display:flex;align-items:center;justify-content:center;
      transition:all 0.15s ease;
      padding:0;
    }
    .tapclosed-opts-close:hover {
      background:rgba(255,255,255,0.08);
      border-color:rgba(255,255,255,0.15);
      color:rgba(255,255,255,0.8);
    }
    .tapclosed-opts-body {
      display:flex;flex-direction:column;gap:8px;padding:16px 12px 20px;
    }
    .tapclosed-opts-option {
      display:flex;align-items:center;gap:14px;padding:14px 16px;
      background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.06);border-radius:12px;
      cursor:pointer;transition:all 0.15s ease;text-align:left;
    }
    .tapclosed-opts-option:hover {
      background:rgba(255,255,255,0.06);
      border-color:rgba(255,255,255,0.12);
      transform:translateX(2px);
    }
    .tapclosed-opts-option:active {
      transform:translateX(0);
    }
    .tapclosed-opts-option-icon {
      width:40px;height:40px;border-radius:10px;
      background:rgba(255,255,255,0.04);
      display:flex;align-items:center;justify-content:center;
      flex-shrink:0;
    }
    .tapclosed-opts-option-content {
      flex:1;
    }
    .tapclosed-opts-option-title {
      font-size:14px;font-weight:600;color:rgba(255,255,255,0.85);margin-bottom:3px;
    }
    .tapclosed-opts-option-desc {
      font-size:12px;color:rgba(255,255,255,0.45);line-height:1.4;
    }
    .tapclosed-opts-divider {
      height:1px;background:rgba(255,255,255,0.06);margin:4px 16px;
    }
  `,o.appendChild(n),e.appendChild(o),requestAnimationFrame(()=>{const p=o.querySelector(".tapclosed-opts-backdrop"),h=o.querySelector(".tapclosed-opts-card");p&&(p.style.opacity="1"),setTimeout(()=>{h&&(h.style.opacity="1",h.style.transform="scale(1) translateY(0)")},30)});const s=o.querySelector(".tapclosed-opts-backdrop"),i=o.querySelector(".tapclosed-opts-close"),a=o.querySelectorAll(".tapclosed-opts-option"),l=()=>F();s.addEventListener("click",l),i.addEventListener("click",l),a.forEach(p=>{p.addEventListener("click",()=>{switch(p.dataset.action){case"domain":v({type:"CLOSE_DOMAIN_TABS"});break;case"other":v({type:"CLOSE_OTHER_TABS"});break;case"all":v({type:"CLOSE_ALL_TABS"});break;case"duplicate":v({type:"DUPLICATE_TAB"});break}F()})});const m=p=>{p.key==="Escape"&&(l(),document.removeEventListener("keydown",m))};document.addEventListener("keydown",m),M=o}function F(){R=!1,M&&(M.style.opacity="0",setTimeout(()=>M?.remove(),250),M=null)}function H(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}function lt(t){switch(d("gesture:",t.type),t.type){case"CLOSE":$();break;case"TAB_NEXT":v({type:"TAB_NEXT"});break;case"TAB_PREV":v({type:"TAB_PREV"});break}}function $(){try{const t=window.location.href,e=Y(t,r.protectionRules);if(e){d("site protected, showing overlay"),G(e);return}D.play("close",{volume:r.soundVolume,enabled:r.soundEnabled});let o=!1;const n=()=>{o||(o=!0,d("sending CLOSE_TAB"),v({type:"CLOSE_TAB",payload:{tabId:0,url:window.location.href,title:document.title}}))},s=J({duration:r.animationDuration,onComplete:n});setTimeout(()=>{s(),n()},r.animationDuration*2+200)}catch(t){X("handleCloseGesture error",t)}}function ct(){let t=null,e=0,o=0;const n=l=>{l.button===1&&(R||(l.preventDefault(),e=l.clientX,o=l.clientY,t=setTimeout(()=>{t=null,rt()},it)))},s=l=>{l.button===1&&t&&(clearTimeout(t),t=null,$())},i=l=>{if(!t)return;const m=l.clientX-e,p=l.clientY-o;Math.sqrt(m*m+p*p)>at&&(clearTimeout(t),t=null)};document.addEventListener("mousedown",n,{capture:!0,passive:!1}),document.addEventListener("mouseup",s,!0),document.addEventListener("mousemove",i,!0);const a=()=>{t&&(clearTimeout(t),t=null)};window.addEventListener("blur",a),document.addEventListener("visibilitychange",a)}if(E())try{chrome.runtime.onMessage.addListener((t,e,o)=>{try{if(t.type==="BG_ERROR"&&(X("background error:",t.payload),o({ok:!0})),t.type==="SHOW_UNDO"){const n=()=>{N(t.payload),D.play("undo",{volume:r.soundVolume,enabled:r.soundEnabled})};if(A)n();else{const s=setInterval(()=>{A&&(clearInterval(s),n())},50);setTimeout(()=>clearInterval(s),5e3)}o({ok:!0})}t.type==="SHOW_PROTECTION"&&(G(t.payload),o({ok:!0}))}catch{}return!0})}catch{}if(E()&&document.addEventListener("keydown",t=>{if(t.ctrlKey&&t.shiftKey&&t.code==="KeyZ"){t.preventDefault();const e=document.getElementById("tapclosed-undo");if(e)e.querySelector(".tapclosed-undo-btn")?.click();else{if(!E())return;chrome.runtime.sendMessage({type:"GET_UNDO_INFO"}).then(o=>{o?.undoInfo&&o.undoInfo.length>0&&(d("keyboard undo:",o.undoInfo.length,"tabs"),v({type:"UNDO_CLOSE"}))}).catch(()=>{})}}},!0),E())try{chrome.storage.onChanged.addListener((t,e)=>{e==="sync"&&t.tapclosed_settings&&(r={...S,...t.tapclosed_settings.newValue})})}catch{}async function K(){d("init, url:",window.location.href);try{const n=await chrome.storage.sync.get("tapclosed_settings");r={...S,...n.tapclosed_settings},d("settings:",r)}catch(n){st("settings load failed:",n),r=S}if(!r.enabled){d("disabled via settings"),A=!0;return}const t=()=>{D.warmUp(),D.isReady()&&document.removeEventListener("mousedown",t,!0)};document.addEventListener("mousedown",t,!0);const e=window.location.href,o=Y(e,r.protectionRules);o&&d("site protected:",o.label),!o&&r.gestureEnabled&&(new g(lt,{closeHoldMs:200,moveThreshold:15,closeCooldownMs:800}).attach(),d("gesture detector attached")),r.gestureEnabled&&(ct(),d("middle click handler attached")),A=!0,d("init complete"),dt()}async function dt(){if(!E())return;let t=null;try{const e=await chrome.runtime.sendMessage({type:"GET_UNDO_INFO"});e?.undoInfo&&Array.isArray(e.undoInfo)&&(t=e.undoInfo)}catch{}if(!t)try{if(chrome.storage?.local){const e=await chrome.storage.local.get("tapclosed_undo_info");e.tapclosed_undo_info&&Array.isArray(e.tapclosed_undo_info)&&(t=e.tapclosed_undo_info)}}catch{}t&&t.length>0&&Date.now()-t[0].closedAt<r.undoDuration+2e3&&(d("found pending undo on init:",t.length,"tabs"),N({tabs:t,count:t.length}),D.play("undo",{volume:r.soundVolume,enabled:r.soundEnabled}))}window.addEventListener("beforeunload",()=>{f?.remove(),f=null}),d("script loaded, readyState:",document.readyState),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>K()):K()})();
